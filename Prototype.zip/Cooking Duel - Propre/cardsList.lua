local cardsList = require("objectsList") -- Création d'une liste d'objets


function cardsList.adjustText(self, text, limit)
  -- Modifie le texte en lui ajoutant des sauts de ligne pour qu'il ne dépasse pas de la carte
  -- TODO
  return text
end

function cardsList.add(self, name, cost, description, effect, typeCard)
  -- Crée une carte et l'ajoute à la liste des cartes
  local card = require("card")
  description = self.adjustText(self, description, 0)
  card.load(card, name, cost, description, typeCard, effect)
  self.list[name] = card
end

-- Définition de tous les effets de carte

function testEffect(self, Game)
  print("Carte jouée !")
  self.delete = true
end


-- Définition de toutes les cartes
cardsList.add(cardsList, "Carte test", 1, "Pas de description.", testEffect, "Test")


return cardsList