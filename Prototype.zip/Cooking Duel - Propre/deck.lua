local deck = {}

function deck.load(self, x, y)
  -- Chargement du deck, x et y sont les coordonnées du deck à l'écran
  self.x = x
  self.y = y
  self.img = love.graphics.newImage("images/cards/back.png")
  self.width = self.img:getWidth()/2
  self.height = self.img:getHeight()/2
  self.cards =   {}
end

function deck.update(self, dt)
  
end

function deck.draw(self)
  -- Dessin du dos de carte du deck
  love.graphics.draw(self.img, self.x, self.y, 0, 0.5, 0.5)
  -- Ecriture du nombre de cartes dans le deck
  love.graphics.setFont(love.graphics.newFont(20))
  love.graphics.setColor(0, 0, 0)
  love.graphics.print(#self.cards, self.x+self.width/2-10, self.y+self.height/2-10)
  love.graphics.setColor(1, 1, 1)
end

function deck.pioche(self)
  -- Récupération et renvoie de la dernière carte du deck
  local id = #self.cards
  if id > 0 then
    local card = self.cards[id]
    table.remove(self.cards, id)
    return card
  else
    return nil
  end
  
end

function deck.shuffle(self)
  -- Mélange du deck
  math.randomseed(love.timer.getTime())
  local shuffledCards = {}
  for i = #self.cards, 1, -1 do
    local n = math.random(i)
    local card = self.cards[n]
    table.insert(shuffledCards, card)
    table.remove(self.cards, n)
  end
  self.cards = shuffledCards
end

return deck