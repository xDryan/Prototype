local card = {}

local fontLittleNumber = love.graphics.newFont(15)
local fontLittleText = love.graphics.newFont(6)
local fontBigNumber = love.graphics.newFont(30)
local fontBigText = love.graphics.newFont(12)

function card.load(self, name, cost, description, cardType, effect)
  self.name = name
  self.cost = cost
  self.description = description
  self.type = typeCard
  self.img = love.graphics.newImage("images/cards/"..name..".png")
  self.x = 0
  self.y = 0
  self.width = self.img:getWidth()/2
  self.height = self.img:getHeight()/2
  self.delete = false
  self.effect = effect
  self.onClick = false
end

function card.update(self, Game, dt)
  if love.mouse.isDown(1) and self.sourisSur(self) then
    if self.onClick == false then
      self.onClick = true
      if Game.Player.energy >= self.cost then
        Game.Player.energy = Game.Player.energy - self.cost
        self.effect(self, Game)
      end
    end
  else
    self.onClick = false
  end
end

function card.draw(self)
  -- Dessin de l'image de la carte et écriture du texte
  love.graphics.draw(self.img, self.x, self.y, 0, 0.5, 0.5)
  love.graphics.setFont(fontLittleNumber)
  love.graphics.setColor(0, 0, 0)
  love.graphics.print(self.cost, self.x + 7, self.y + 5)
  love.graphics.setFont(fontLittleText)
  love.graphics.print(self.name, self.x + 30, self.y + 10)
  love.graphics.print(self.description, self.x + 10, self.y + 105)
  love.graphics.setColor(1, 1, 1)
  if self.sourisSur(self) then
    -- Dessin du halo autour la miniature
    love.graphics.setColor(0, 1, 0)
    love.graphics.rectangle("line", self.x, self.y, self.width, self.height)
    love.graphics.setColor(1, 1, 1)
    -- Dessin de la carte en grand
    local x = 200
    local y = 100
    love.graphics.draw(self.img, x, y)
    love.graphics.setColor(0, 0, 0)
    love.graphics.setFont(fontBigNumber)
    love.graphics.print(self.cost, x + 15, y + 10)
    love.graphics.setFont(fontBigText)
    love.graphics.print(self.name, x + 60, y + 20)
    love.graphics.print(self.description, x + 20, y + 210)
    love.graphics.setColor(1, 1, 1)
  end
end

function card.sourisSur(obj)
  -- Renvoie TRUE si la souris est sur l'objet, FALSE sinon.
  local res = false
  local mouseX = love.mouse.getX()
  local mouseY = love.mouse.getY()
  local xMin = obj.x
  local xMax = obj.x + obj.width
  local yMin = obj.y
  local yMax = obj.y + obj.height
  if mouseX >= xMin and mouseX <= xMax and mouseY >= yMin and mouseY <= yMax then
    res = true
  end
  return res
end

return card