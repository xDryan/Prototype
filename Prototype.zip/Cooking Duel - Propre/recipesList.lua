local recipesList = require("objectsList")


function recipesList.add(self, name, ingredients, points)
  local recipe = {}
  recipe.name = name
  recipe.ingredients = ingredients
  recipe.points = points
  self.list[name] = recipe
end

function recipesList.validRecipe(self, ingredients)
  local recipe
  local goodRecipe = true
  for recipe in self.list do
    if #recipe.ingredients == #ingredients then
      for i = 1, #recipe.ingredients do
        if recipe.ingredients[i] ~= ingredients[i] then
          goodRecipe = false
        end
      end
      if goodRecipe then
        print(recipe.name.." est cuisiné !")
        return recipe.points
      else
        goodRecipe = true
      end
    end
  end
end

-- Ecriture de toutes les recettes
recipesList.add(recipesList, "Recipe Test", {"Aliment test", "Aliment test"}, 5)

return recipesList