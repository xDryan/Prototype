local Game = {}

function Game.load(self)
  -- Chargement des différents éléments de jeu
  Game.Player = require("player")
  Game.Player.load(Game.Player)
  --Game.Enemy = require("enemy")
  --Game.Enemy.load(Game.Enemy)
  
  -- Création des listes d'éléments nécessaires au jeu
  Game.recipesList = require("recipesList")
  Game.containersList = require("containersList")
  Game.cardsList = require("cardsList")
  --Game.passivesList = require("passivesList")
  -- Tour de jeu
  Game.turn = 0
  -- Remplissage du deck du joueur
  for i = 1, 10 do
    local card = Game.cardsList.get(Game.cardsList, "Carte test")
    table.insert(Game.Player.deck.cards, card)
  end
end



function Game.update(self, dt)
  -- Seuls le joueur et l'ennemi ont besoin d'être mis à jour
  Game.Player.update(Game.Player, Game, dt)
  --Game.Enemy.update(Game.Enemy, Game, dt)
end


function Game.draw(self)
  -- Dessin des éléments du jeu
  Game.Player.draw(Game.Player)
  --Game.Enemy.draw(Game.Enemy)
end

function Game.keypressed(self, key)
  -- On quitte le jeu si le joueur appuie sur échap
  if key == "escape" then
    love.event.quit()
  end
  self.Player.keypressed(self.Player, key)
end

return Game