local containersList = require("objectsList")

function containersList.add(self, name, capacity)
  local container = require("container")
  container.name = name
  container.capacity = capacity
  self.list[name] = container
end



return containersList