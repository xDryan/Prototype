local objectsList = {}

objectsList.list = {}

function objectsList.add(self, object)
  -- Ajoute l'objet passé en paramètre à la liste
  local name = object.name
  self.list[name] = object
end

function objectsList.get(self, name)
  -- Renvoie la copie d'un élément de base du jeu (ex : une carte, un récipient, etc.)
  local objectCopy = {}
  
  for key, value in pairs(self.list[name]) do
    objectCopy[key] = value
  end
  
  return objectCopy
end

return objectsList
