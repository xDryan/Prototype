local Player = {}

function Player.load(self)
  -- Chargement du deck
  self.deck = require("deck")
  self.deck.load(self.deck, 875, 425)
  -- Chargement de la main
  self.hand = require("hand")
  self.hand.load(self.hand, 20, 425, 7)
  -- Chargement des récipients
  self.containers = {}
  -- Initialisation des variables
  self.maxEnergy = 1
  self.energy = 1
  self.energyImg = love.graphics.newImage("images/energie.png")
  self.emptyEnergyImg = love.graphics.newImage("images/energie_vide.png")
  self.passives = {}
  self.points = 0
  -- Chargement du bouton "Fin de tour"
  self.nextTurnButton = require("button")
  self.nextTurnButton.load(self.nextTurnButton, 25, 100, "Fin de tour", nextTurnAction, self)
  self.nextTurnButton.x = 875
  self.nextTurnButton.y = 15
  self.nextTurnButton.textX = self.nextTurnButton.x + 5
  self.nextTurnButton.textY = self.nextTurnButton.y + 3
end

function Player.update(self, Game, dt)
  -- Mise à jour des différents éléments du joueur
  self.deck.update(self.deck, dt)
  self.hand.update(self.hand, Game, dt)
  self.nextTurnButton.update(self.nextTurnButton, Game, dt)
end

function Player.draw(self)
  -- Dessin des récipients
  for i = 1, #self.containers do
    local container = self.containers[i]
    container.draw(self.container)
  end
  -- Ecriture du score
  love.graphics.setFont(love.graphics.newFont(25))
  love.graphics.print("Points : "..self.points, 600, 25)
  -- Dessin du bouton Tour suivant
  self.nextTurnButton.draw(self.nextTurnButton)
  -- Dessin des énergies
  local x = 900
  local y = 50
  for i = 10, 1, -1 do
    if i > self.energy then
      love.graphics.draw(self.emptyEnergyImg, x, y, 0, 0.5, 0.5)
    else
      love.graphics.draw(self.energyImg, x, y, 0, 0.5, 0.5)
    end
    y = y + self.energyImg:getHeight()/2 + 5
  end
  -- Dessin du deck et de la main
  self.deck.draw(self.deck)
  self.hand.draw(self.hand)
  
end

function nextTurnAction(button, Game)
  -- Avance du tour de jeu
  Game.turn = Game.turn + 1
  -- Augmentation de l'énergie si elle n'a pas atteint 10
  if button.object.maxEnergy < 10 then
    button.object.maxEnergy = button.object.maxEnergy + 1
  end
  -- Remplissage de l'énergie
  button.object.energy = button.object.maxEnergy
end

function Player.keypressed(self, key)
  -- Pour les tests, on pioche en appuyant sur espace
  if key == "space" then
    local card = self.deck.pioche(self.deck)
    if card ~= nil then
      table.insert(self.hand.cards, card)
    end
  end
end

return Player