local hand = {}

function hand.load(self, x, y, capacity)
  -- x est l'écart entre les cartes, y la position y des cartes de la main
  hand.x = x
  hand.y = y
  hand.capacity = capacity
  hand.cards = {}
end

function hand.update(self, Game, dt)
  -- Suppression des cartes en trop (limite du nombre de cartes en main)
  for i = #self.cards, 1, -1 do
    if i > self.capacity then
      table.remove(self.cards, i)
    -- Suppression de la carte si elle a été joué
    elseif self.cards[i].delete then
      table.remove(self.cards, i)
      if #self.cards >= i then
        self.cards[i].onClick = true
      end
    else
      -- Mise à jour de la position de la carte
      local card = self.cards[i]
      card.y = hand.y
      card.x = hand.x + (card.img:getWidth()/2 + hand.x) * (i-1)
      card.update(card, Game, dt)
    end
  end
end

function hand.draw(self)
  -- Dessin des cartes de la main
  for i = 1,  #self.cards do
    local card = self.cards[i]
    card.draw(card)
  end
end


return hand