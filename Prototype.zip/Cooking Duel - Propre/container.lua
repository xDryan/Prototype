local container = {}

function container.load(self, name, capacity)
  self.name = name
  self.capacity = capacity
  self.img = love.graphics.newImage("images/containers/"..name..".png")
  self.x = 0
  self.y = 0
  self.width = self.img:getWidth()
  self.height = self.img:getHeight()
  self.hasButton = true
  self.button = require("button")
  self.contents = {}
  self.isCurrent = false
  self.button.load(self.button, self.height, self.width, "Use", buttonAction, self)
end

function container.update(self, Game, dt)
  -- Changer le récipient courant
  if love.mouse.isDown(1) then
    if self.onClick == false then
      self.onClick = true
      if self.hasButton then
        Game.Player.currentContainer.isCurrent = false
        Game.Player.currentContainer = self
        self.isCurrent = true
      end
    end
  else
    self.onClick = false
  end
  -- Mise à jour du bouton
  self.button.update(self, Game, dt)
end

function container.draw(self)
  -- Dessin du récipient
  love.graphics.draw(self.img, self.x, self.y)
  if self.isCurrent then
    love.graphics.rectangle("line", self.x - 3, self.y - 3, self.width + 6, self.height + 6)
  end
  -- Dessin du bouton
  self.button.x = self.x
  self.button.y = self.y + self.height + 5
  self.button.draw(self.button)
end

function buttonAction(button, Game)
  -- On vérifie que le contenu du récipient correspond à une recette existante
  local points = Game.recipesList.validRecipe(Game.recipesList, self.contents)
  if points == 0 then
    print("Le récipient est vide !")
  elseif points > 0 then
    print("Vous avez gagné "..points.." points !")
  else
    print("Vous avez perdu "..points.." points !")
  end
  Game.Player.points = Game.Player.points + points
  button.object.contents = {}
end

function container.sourisSur(obj)
  -- Renvoie TRUE si la souris est sur l'objet, FALSE sinon.
  local res = false
  local mouseX = love.mouse.getX()
  local mouseY = love.mouse.getY()
  local xMin = obj.x
  local xMax = obj.x + obj.width
  local yMin = obj.y
  local yMax = obj.y + obj.height
  if mouseX >= xMin and mouseX <= xMax and mouseY >= yMin and mouseY <= yMax then
    res = true
  end
  return res
end

return container