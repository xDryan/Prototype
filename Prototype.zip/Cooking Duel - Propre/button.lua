local button = {}

function button.load(self, height, width, text, action, object)
  button.text = text
  button.x = 0
  button.y = 0
  button.width = width
  button.height = height
  button.textX = self.width/3
  button.textY = self.height/3
  button.color = {1, 1, 1}
  button.colorHalo = {0, 1, 0}
  button.colorText = {0, 0, 0}
  button.action = action
  button.onClick = false
  button.object = object
end

function button.update(self, Game, dt)
  if love.mouse.isDown(1) and self.sourisSur(self) then
    if self.onClick == false then
      self.onClick = true
      self.action(self, Game)
    end
  else
    self.onClick = false
  end
end

function button.draw(self)
  -- Dessin du bouton
  if self.sourisSur(self) then
    love.graphics.setColor(self.colorHalo)
  else
    love.graphics.setColor(self.color)
  end
  love.graphics.rectangle("fill", self.x, self.y, self.width, self.height)
  love.graphics.setColor(self.colorText)
  love.graphics.setFont(love.graphics.newFont(15))
  love.graphics.print(self.text, self.textX, self.textY)
  love.graphics.setColor(1, 1, 1)
end

function button.sourisSur(obj)
  -- Renvoie TRUE si la souris est sur l'objet, FALSE sinon.
  local res = false
  local mouseX = love.mouse.getX()
  local mouseY = love.mouse.getY()
  local xMin = obj.x
  local xMax = obj.x + obj.width
  local yMin = obj.y
  local yMax = obj.y + obj.height
  if mouseX >= xMin and mouseX <= xMax and mouseY >= yMin and mouseY <= yMax then
    res = true
  end
  return res
end


return button