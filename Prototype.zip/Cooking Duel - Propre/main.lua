-- Cette ligne permet d'afficher des traces dans la console pendant l'éxécution
io.stdout:setvbuf('no')

-- Empèche Love de filtrer les contours des images quand elles sont redimentionnées
-- Indispensable pour du pixel art
love.graphics.setDefaultFilter("nearest")

-- Cette ligne permet de déboguer pas à pas dans ZeroBraneStudio
if arg[#arg] == "-debug" then require("mobdebug").start() end

function love.load()
  -- Définition des paramètres de base
  love.window.setMode(1000, 600)
  largeur_ecran = love.graphics.getWidth()
  hauteur_ecran = love.graphics.getHeight()
  
  -- Création et chargement du jeu
  Game = require("game")
  Game.load(Game)
end

function love.update(dt)
  -- Mise à jour du jeu
  Game.update(Game, dt)
end

function love.draw()
  -- Dessin du jeu à l'écran
  Game.draw(Game)
end

function love.keypressed(key)
  -- Effet des touches pressées dans le jeu
  Game.keypressed(Game, key)
  
end
  